"""Week 2 exercise - same question with and without context, on the local model.

    python exercises/week2_prompt_experiment.py
"""
import warnings

from foundry_local_sdk import Configuration, FoundryLocalManager

CONTEXT = ("Mentors hold office hours every Tuesday and Thursday from 15:00 to 16:30 in Lab 2. "
           "Outside office hours post questions in the course forum.")
QUESTION = "When and where are the summer school office hours?"
SYSTEM = ("Answer using only the provided context. If the context does not contain the answer, "
          "say \"I don't know\".")


def main() -> None:
    FoundryLocalManager.initialize(Configuration(app_name="prompt_experiment"))
    model = FoundryLocalManager.instance.catalog.get_model("qwen2.5-0.5b")
    model.download(lambda p: print(f"\rDownloading: {p:5.1f}%", end="", flush=True))
    print()
    model.load()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        chat = model.get_chat_client()
    chat.settings.temperature = 0.1

    def ask(messages):
        return chat.complete_chat(messages).choices[0].message.content.strip()

    print("1) No context (model will guess / hallucinate):")
    print("  ", ask([{"role": "user", "content": QUESTION}]))
    print("\n2) System rule + context:")
    print("  ", ask([{"role": "system", "content": SYSTEM},
                     {"role": "user", "content": f"Context: {CONTEXT}\n\nQuestion: {QUESTION}"}]))
    print("\n3) System rule + UNRELATED question (should say I don't know):")
    print("  ", ask([{"role": "system", "content": SYSTEM},
                     {"role": "user", "content": f"Context: {CONTEXT}\n\nQuestion: What is the capital of Australia?"}]))
    model.unload()


if __name__ == "__main__":
    main()
