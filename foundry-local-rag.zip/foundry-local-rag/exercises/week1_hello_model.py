"""Week 1 exercise - "Hello Model": verify Foundry Local works on this machine.

    python exercises/week1_hello_model.py [model-alias]

Downloads (first run only), loads a small chat model and completes a greeting.
"""
import sys
import time
import warnings

from foundry_local_sdk import Configuration, FoundryLocalManager

ALIAS = sys.argv[1] if len(sys.argv) > 1 else "qwen2.5-0.5b"


def main() -> None:
    FoundryLocalManager.initialize(Configuration(app_name="hello_model"))
    manager = FoundryLocalManager.instance

    model = manager.catalog.get_model(ALIAS)
    if model is None:
        sys.exit(f"'{ALIAS}' not in catalog. Try: python main.py models")
    model.download(lambda p: print(f"\rDownloading {ALIAS}: {p:5.1f}%", end="", flush=True))
    print()
    model.load()

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        client = model.get_chat_client()

    t0 = time.perf_counter()
    messages = [{"role": "user", "content": "Complete this greeting in one friendly sentence: Hello, world"}]
    print("Model: ", end="", flush=True)
    for chunk in client.complete_streaming_chat(messages):
        if chunk.choices and chunk.choices[0].delta.content:
            print(chunk.choices[0].delta.content, end="", flush=True)
    print(f"\n\nOK - Foundry Local is working ({time.perf_counter() - t0:.1f}s).")
    model.unload()


if __name__ == "__main__":
    main()
