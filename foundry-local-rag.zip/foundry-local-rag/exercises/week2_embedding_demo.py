"""Week 2 exercise - embeddings + cosine similarity search (in memory).

    python exercises/week2_embedding_demo.py ["your query"]
"""
import math
import sys
import warnings

from foundry_local_sdk import Configuration, FoundryLocalManager

SENTENCES = [
    "The capital of France is Paris.",
    "SQLite stores a whole database in a single file.",
    "Embeddings turn text into vectors that capture meaning.",
    "Phi-3.5-mini is a small language model that runs on a laptop.",
    "Football is the most popular sport in Turkey.",
    "Cosine similarity compares the direction of two vectors.",
]
QUERY = sys.argv[1] if len(sys.argv) > 1 else "How can I measure how similar two pieces of text are?"


def cosine_similarity(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def find_relevant(query_embedding, doc_embeddings, top_k=3):
    scores = [(i, cosine_similarity(query_embedding, d)) for i, d in enumerate(doc_embeddings)]
    return sorted(scores, key=lambda s: s[1], reverse=True)[:top_k]


def main() -> None:
    FoundryLocalManager.initialize(Configuration(app_name="embedding_demo"))
    model = FoundryLocalManager.instance.catalog.get_model("qwen3-embedding-0.6b")
    model.download(lambda p: print(f"\rDownloading embedding model: {p:5.1f}%", end="", flush=True))
    print()
    model.load()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        client = model.get_embedding_client()

    doc_vecs = [d.embedding for d in client.generate_embeddings(SENTENCES).data]
    q_vec = client.generate_embedding(QUERY).data[0].embedding
    print(f"Vector size: {len(q_vec)} dimensions\nQuery: {QUERY}\n")
    for i, score in find_relevant(q_vec, doc_vecs):
        print(f"  {score:.3f}  {SENTENCES[i]}")
    model.unload()


if __name__ == "__main__":
    main()
