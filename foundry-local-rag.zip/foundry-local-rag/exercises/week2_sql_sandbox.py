"""Week 2 exercise - SQL sandbox with Python's built-in sqlite3 (no models needed).

    python exercises/week2_sql_sandbox.py
"""
import json
import sqlite3

conn = sqlite3.connect(":memory:")  # use "sandbox.db" to keep the file
conn.execute("CREATE TABLE documents (id INTEGER PRIMARY KEY, content TEXT NOT NULL, embedding TEXT)")

rows = [
    ("RAG retrieves passages before generating an answer.", [0.9, 0.1, 0.0]),
    ("SQLite is a serverless database in a single file.", [0.1, 0.8, 0.2]),
    ("Foundry Local runs models on your own laptop.", [0.3, 0.2, 0.9]),
]
conn.executemany("INSERT INTO documents(content, embedding) VALUES (?, ?)",
                 [(text, json.dumps(vec)) for text, vec in rows])
conn.commit()

print("All rows:")
for r in conn.execute("SELECT id, content FROM documents"):
    print("  ", r)

print("\nBy id = 2:")
print("  ", conn.execute("SELECT content FROM documents WHERE id = ?", (2,)).fetchone())

print("\nKeyword filter LIKE '%laptop%':")
for r in conn.execute("SELECT id, content FROM documents WHERE content LIKE ?", ("%laptop%",)):
    print("  ", r)

vec = json.loads(conn.execute("SELECT embedding FROM documents WHERE id = 1").fetchone()[0])
print(f"\nEmbedding of row 1 read back from JSON: {vec}")
print("\nNext step: the real project stores vectors as float32 BLOBs - see rag/store.py")
