#!/usr/bin/env bash
# macOS / Linux setup: creates .venv, installs deps, runs tests, builds the index.
set -euo pipefail
python3 -m venv .venv
.venv/bin/python -c "import sys; assert sys.version_info >= (3, 11), 'Python 3.11+ required'"
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pytest -q
.venv/bin/python main.py ingest
echo -e "\nDone. Activate with:  source .venv/bin/activate   then:  python main.py chat   or   python main.py serve"
