"""Week 5 - systematic evaluation of the assistant.

    python eval/run_eval.py            (real Foundry Local models)
    python eval/run_eval.py --mock     (fake models, checks the plumbing only)

Metrics
  retrieval hit@k   expected source file is among the retrieved chunks (answerable questions)
  answer keywords   every expected keyword appears in the answer (case-insensitive)
  refusal correct   unanswerable questions get the fallback answer; answerable ones do NOT
  latency           retrieval + generation time per question
Writes eval/results.md and eval/results.csv.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))


def is_refusal(answer: str) -> bool:
    a = answer.lower()
    return "don't have that information" in a or "do not have that information" in a or "type a question" in a


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--questions", default=str(HERE / "questions.json"))
    args = ap.parse_args()
    if args.mock:
        os.environ["RAG_BACKEND"] = "mock"
        os.environ.setdefault("RAG_DB_PATH", str(HERE.parent / "data" / "rag_mock.db"))

    from rag import RagPipeline
    from rag.ingest import ingest

    rag = RagPipeline()
    ingest(rag.settings, rag.store, rag.embedder, verbose=False)  # make sure index is current
    questions = json.loads(Path(args.questions).read_text(encoding="utf-8"))

    rows = []
    for q in questions:
        ans = rag.answer_query(q["question"])
        sources = [h.source for h in ans.sources]
        refused = is_refusal(ans.answer)
        row = {
            "id": q["id"], "question": q["question"].strip() or "(empty)", "answerable": q["answerable"],
            "answer": ans.answer.replace("\n", " "), "sources": ";".join(sources),
            "top_score": round(ans.sources[0].score, 3) if ans.sources else "",
            "retrieval_ms": round(ans.retrieval_ms, 1), "generation_ms": round(ans.generation_ms, 1),
        }
        if q["answerable"]:
            row["hit"] = q["expected_source"] in sources
            row["keywords_ok"] = all(k.lower() in ans.answer.lower() for k in q.get("keywords", []))
            row["refusal_ok"] = not refused
        else:
            row["hit"] = ""
            row["keywords_ok"] = ""
            row["refusal_ok"] = refused
        row["pass"] = bool(row["refusal_ok"] and (not q["answerable"] or (row["hit"] and row["keywords_ok"])))
        rows.append(row)
        print(f"{'PASS' if row['pass'] else 'FAIL'}  {q['id']}  {row['question'][:60]}")

    ans_rows = [r for r in rows if r["answerable"]]
    un_rows = [r for r in rows if not r["answerable"]]
    pct = lambda n, d: f"{100 * n / d:.0f}% ({n}/{d})" if d else "n/a"
    total_ms = [r["retrieval_ms"] + r["generation_ms"] for r in rows if r["generation_ms"]]
    summary = {
        "backend": rag.settings.backend,
        "chat_model": rag.chat.name if any(r["generation_ms"] for r in rows) else "-",
        "embedding_model": rag.embedder.name,
        "retrieval hit@k (answerable)": pct(sum(r["hit"] for r in ans_rows), len(ans_rows)),
        "answer keywords present": pct(sum(r["keywords_ok"] for r in ans_rows), len(ans_rows)),
        "answered when it should": pct(sum(r["refusal_ok"] for r in ans_rows), len(ans_rows)),
        "refused when it should": pct(sum(r["refusal_ok"] for r in un_rows), len(un_rows)),
        "overall pass": pct(sum(r["pass"] for r in rows), len(rows)),
        "median latency (LLM calls)": f"{statistics.median(total_ms):.0f} ms" if total_ms else "n/a",
        "max latency (LLM calls)": f"{max(total_ms):.0f} ms" if total_ms else "n/a",
    }

    with open(HERE / "results.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    md = ["# Evaluation results", "", "| Metric | Value |", "|---|---|"]
    md += [f"| {k} | {v} |" for k, v in summary.items()]
    md += ["", "| ID | Question | Pass | Hit | Keywords | Refusal OK | Top score | ms | Answer |",
           "|---|---|---|---|---|---|---|---|---|"]
    fmt = lambda v: "" if v == "" else ("yes" if v else "NO")
    for r in rows:
        md.append(f"| {r['id']} | {r['question']} | {fmt(r['pass'])} | {fmt(r['hit'])} | {fmt(r['keywords_ok'])} | "
                  f"{fmt(r['refusal_ok'])} | {r['top_score']} | {r['retrieval_ms'] + r['generation_ms']:.0f} | "
                  f"{r['answer'][:160].replace('|', '/')} |")
    (HERE / "results.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    print()
    for k, v in summary.items():
        print(f"  {k:32s} {v}")
    print(f"\nWrote {HERE / 'results.md'} and results.csv")


if __name__ == "__main__":
    main()
