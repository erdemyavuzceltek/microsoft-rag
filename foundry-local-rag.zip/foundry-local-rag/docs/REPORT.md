# Project Report — Local RAG Assistant

## 1. Problem statement

Students and staff of a (fictional) summer school keep asking the same questions about the schedule,
tooling and course material. Answers exist in a handful of documents, but searching them by hand is
slow, and a general chatbot invents answers it does not know. Goal: an assistant that answers **only
from our documents**, cites where each answer came from, admits when it does not know, and runs
**entirely offline on a student laptop**.

## 2. Architecture

| Layer | Implementation |
|---|---|
| Client | Terminal chat (`main.py chat`) and a static HTML/JS page served by Flask (`main.py serve`) |
| Pipeline | `rag/pipeline.py` — embed question → search → build prompt → generate |
| Data | SQLite file `data/rag.db`: `documents`, `chunks` (text + float32 BLOB embedding), `meta` |
| AI | Microsoft Foundry Local SDK: `qwen3-embedding-0.6b` for embeddings, `phi-3.5-mini` for chat, both in-process on CPU/GPU/NPU |

Flow: **ingest** (offline, once) → chunk → embed → store. **Query** → embed question with the same model →
brute-force cosine similarity over all chunk vectors (cached in a numpy matrix) → keep top-3 above the
score threshold → numbered context + question → local LLM → answer with `[n]` citations.

## 3. Design decisions

| Decision | Why | Trade-off |
|---|---|---|
| Heading-aware chunks, ~900 chars, 150 overlap | Keeps a paragraph with its heading; heading path becomes the citation | Character-based, not token-based |
| Prepend title + section to the text before embedding | Short paragraphs gain context ("Windows" → "Setup Guide > Installing > Windows") | Slightly longer embedding inputs |
| float32 BLOB instead of JSON | 4× smaller, loads straight into numpy | Not human-readable in a DB browser |
| Brute-force cosine in numpy, matrix cached | Milliseconds for thousands of chunks, zero extra dependencies | O(N) per query; use sqlite-vec / ANN index past ~100k chunks |
| Score threshold → refuse **without** calling the LLM | Cheapest and most reliable anti-hallucination guard; saves seconds per off-topic question | Too high a threshold refuses valid questions — tune with the eval |
| Strict system prompt + exact fallback sentence | Makes refusals machine-checkable in the evaluation | Small models sometimes paraphrase it |
| Temperature 0.1 | Deterministic, factual answers | Less varied wording |
| SHA-256 incremental ingestion | Re-running ingest only embeds changed files | — |
| Embedding model name stored in `meta` | Prevents silently mixing vectors from different models | Model change forces a rebuild |
| Mock backend | Tests and demos run on machines without Foundry Local; CI-friendly | Mock answers are not real LLM output |
| Chat model lazily loaded | `ingest` never loads the (large) chat model | First question is slower |

## 4. Testing and evaluation

**Unit/integration tests** (`python -m pytest -q`, 11 tests): chunking (headings, size, overlap, empty input),
store (round-trip, ranking, threshold, replace, dimension mismatch), incremental ingestion (unchanged /
updated / removed), pipeline (citation, refusal without LLM, empty question), prompt format, and the web API.

**Evaluation** (`python eval/run_eval.py`): 20 questions in `eval/questions.json` — 14 answerable (with
expected source file and keywords), 5 unanswerable, 1 empty-input edge case. Metrics: retrieval hit@k,
keyword presence, correct answer/refusal behaviour, latency. Results are written to `eval/results.md`.

Plumbing check with the mock backend: retrieval hit@k 100% (14/14). Keyword/refusal scores in mock mode
only reflect the fake extractive "LLM" and are not meaningful.

> **Fill in after running on your laptop with real models:**
>
> | Metric | Value |
> |---|---|
> | Hardware (CPU / RAM / GPU-NPU) | |
> | Chat model | phi-3.5-mini |
> | Retrieval hit@k | |
> | Answer keywords present | |
> | Refused when it should | |
> | Median / max latency | |
>
> Plan target: roughly 1–3 s per question on a typical laptop for small models.

## 5. Limitations and future work

- Only `.md` / `.txt` input — PDF/DOCX would need a text extractor (e.g. `pypdf`, `python-docx`).
- Single-turn Q&A; follow-up questions ("and on macOS?") lose context. Could add query rewriting with chat history.
- Brute-force search; switch to `sqlite-vec` for large corpora.
- No re-ranking; a cross-encoder or hybrid keyword + vector search would improve precision.
- Citation correctness depends on the small model following instructions.

## 6. Demo-day presentation outline (6 min + 4 min Q&A)

1. **Problem** (1 min) — repetitive questions, hallucinating chatbots, need for offline/privacy.
2. **How it works** (1.5 min) — architecture diagram above: retrieve → augment → generate; SQLite + Foundry Local.
3. **Live demo** (2.5 min) — `python main.py serve`:
   - "How much RAM do I need to run Foundry Local?" → cited answer, open sources panel.
   - "What percentage of the grade is the final presentation?" → exact figure with citation.
   - "How much does the summer school cost?" → "I don't have that information in my documents."
   - Pull the network cable / airplane mode to prove it is offline.
4. **Results** (0.5 min) — evaluation table.
5. **Lessons learned** (0.5 min) — e.g. chunking with headings mattered most for retrieval quality; the
   score threshold was the simplest effective hallucination guard; small models need short, explicit rules.

## 7. References

- Tech Community — Building your first local RAG application with Foundry Local (community blog)
- Microsoft Learn — Tutorial: Build a RAG application; Generate text embeddings; Get started with Foundry Local
- sqlite.org documentation
