"""Local RAG Assistant - command line entry point.

    python main.py ingest [--rebuild]     build / update the SQLite index from knowledge_base/
    python main.py chat                   interactive Q&A in the terminal (Option A: CLI)
    python main.py ask "question"         one-shot question
    python main.py serve [--port 8000]    web UI at http://127.0.0.1:8000 (Option C: HTML+JS)
    python main.py stats                  what is in the index
    python main.py models                 list Foundry Local catalog aliases

Add --mock before the command to run without Foundry Local (fake models, for testing).
"""
from __future__ import annotations

import argparse
import os
import sys


def _pipeline():
    from rag import RagPipeline
    return RagPipeline()


def cmd_ingest(args) -> None:
    from rag.config import get_settings
    from rag.ingest import ingest
    from rag.models import get_embedder
    from rag.store import VectorStore

    s = get_settings()
    store = VectorStore(s.db_path)
    print(f"[ingest] docs: {s.docs_dir}\n[ingest] db:   {s.db_path}\n[ingest] embedder backend: {s.backend}")
    report = ingest(s, store, get_embedder(s), rebuild=args.rebuild)
    print(f"[ingest] done: {report.summary()}")
    print(f"[ingest] index: {store.stats()}")


def _print_sources(hits) -> None:
    if hits:
        print("\n  sources:")
        for i, h in enumerate(hits, 1):
            print(f"   [{i}] {h.citation}  (score {h.score:.2f})")


def cmd_ask(args) -> None:
    ans = _pipeline().answer_query(args.question)
    print(ans.answer)
    _print_sources(ans.sources)
    print(f"\n  retrieval {ans.retrieval_ms:.0f} ms | generation {ans.generation_ms:.0f} ms")


def cmd_chat(args) -> None:
    rag = _pipeline()
    st = rag.store.stats()
    if not st["chunks"]:
        sys.exit("Index is empty. Run: python main.py ingest")
    print(f"Local RAG Assistant - {st['documents']} docs / {st['chunks']} chunks. "
          "Type 'exit' to quit, ':sources' to toggle source display.")
    show_sources = True
    print("(loading chat model on first question...)")
    while True:
        try:
            q = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if q.lower() in {"exit", "quit", ":q"}:
            break
        if q == ":sources":
            show_sources = not show_sources
            print(f"source display {'on' if show_sources else 'off'}")
            continue
        if not q:
            continue
        hits, tokens = rag.stream_answer(q)
        print("Assistant: ", end="", flush=True)
        for t in tokens:
            print(t, end="", flush=True)
        print()
        if show_sources:
            _print_sources(hits)


def cmd_serve(args) -> None:
    from web.server import create_app
    app = create_app(_pipeline())
    print(f"Open http://{args.host}:{args.port}  (Ctrl+C to stop)")
    app.run(host=args.host, port=args.port, threaded=True)


def cmd_stats(args) -> None:
    from rag.config import get_settings
    from rag.store import VectorStore
    store = VectorStore(get_settings().db_path)
    print(store.stats())
    for d in store.list_documents():
        print(f"  {d['chunks']:3d} chunks  {d['source']}  ({d['title']})")


def cmd_models(args) -> None:
    from rag.config import get_settings
    from rag.models import _get_manager
    mgr = _get_manager(get_settings())
    cached = {m.alias for m in mgr.catalog.get_cached_models()}
    for alias in sorted({m.alias for m in mgr.catalog.list_models()}):
        print(f"  {'*' if alias in cached else ' '} {alias}")
    print("\n  * = already downloaded")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="Local RAG assistant (Microsoft Foundry Local + SQLite)")
    p.add_argument("--mock", action="store_true", help="use fake offline models (no Foundry Local needed)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("ingest"); s.add_argument("--rebuild", action="store_true"); s.set_defaults(fn=cmd_ingest)
    s = sub.add_parser("ask"); s.add_argument("question"); s.set_defaults(fn=cmd_ask)
    sub.add_parser("chat").set_defaults(fn=cmd_chat)
    s = sub.add_parser("serve"); s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8000); s.set_defaults(fn=cmd_serve)
    sub.add_parser("stats").set_defaults(fn=cmd_stats)
    sub.add_parser("models").set_defaults(fn=cmd_models)

    args = p.parse_args(argv)
    if args.mock:
        os.environ["RAG_BACKEND"] = "mock"
        os.environ.setdefault("RAG_DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "rag_mock.db"))
    args.fn(args)


if __name__ == "__main__":
    main()
