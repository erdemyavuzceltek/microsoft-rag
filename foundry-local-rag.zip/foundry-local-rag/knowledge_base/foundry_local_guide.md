# Foundry Local Setup Guide

## What is Foundry Local

Microsoft Foundry Local is an on-device AI runtime. It downloads optimised models from a curated catalog, manages them in a local cache and runs inference on the CPU, GPU or NPU of your own computer. No cloud account, subscription or API key is needed, and after a model has been downloaded no internet connection is required.

## System Requirements

Foundry Local runs on Windows 10 or later, Windows Server 2025, and macOS. It needs at least 8 GB of RAM and 3 GB of free disk space; 16 GB of RAM and 15 GB of free disk space are recommended. A GPU or NPU is optional; the runtime automatically picks the best available hardware. The Python SDK requires Python 3.11 or later.

## Installing the Python SDK

On Windows install the WinML build with: pip install foundry-local-sdk-winml openai. On macOS and Linux install: pip install foundry-local-sdk openai. In this project simply run pip install -r requirements.txt, which picks the right package for your operating system.

## Models Used in This Project

The chat model is phi-3.5-mini, a small language model of about 3.8 billion parameters that gives a good balance of speed and quality on a laptop. On machines with only 8 GB of RAM use qwen2.5-0.5b instead by setting the environment variable RAG_CHAT_MODEL. The embedding model is qwen3-embedding-0.6b. Always use the same embedding model for ingestion and for questions; vectors from different models cannot be compared.

## First Run

The first time the assistant starts it downloads the models into the Foundry Local cache, which can take several minutes and needs internet. Every later run loads the models from the cache and works fully offline.

## Troubleshooting

If a model alias is not found, run python main.py models to list the aliases available in the catalog. If answers are very slow, switch to a smaller chat model, reduce top-k, or close other memory-hungry applications. If you change the embedding model, rebuild the index with python main.py ingest --rebuild.
