# SQLite Basics for the Project

## Why SQLite

SQLite is a serverless, self-contained SQL database engine. The whole database is a single file, there is no server to install or configure, it works on Windows, macOS and Linux, and Python includes it in the standard library through the sqlite3 module. It is the most widely deployed database engine in the world.

## Database Schema

The project database has three tables. The documents table stores one row per source file with its path, title, a SHA-256 hash of its content and the ingestion time. The chunks table stores each passage with its section heading, text and embedding vector. The meta table remembers which embedding model built the index.

## How Embeddings Are Stored

Each embedding is stored in a BLOB column as 32-bit floating point numbers, four bytes per dimension. This is about four times smaller than storing the vector as JSON text and loads directly into a numpy array.

## Incremental Ingestion

When ingestion runs again, the SHA-256 hash of every document is compared with the stored hash. Unchanged documents are skipped, changed documents are re-chunked and re-embedded, and documents deleted from the folder are removed from the database.

## Useful SQL

To count chunks run SELECT COUNT(*) FROM chunks. To see chunks per document run a query that joins documents and chunks and groups by document. You can open the database file with the sqlite3 command-line tool or DB Browser for SQLite.
