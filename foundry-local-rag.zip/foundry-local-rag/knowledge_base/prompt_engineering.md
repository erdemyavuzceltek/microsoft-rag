# Prompt Engineering for Q&A

## System and User Messages

Chat models receive a list of messages. The system message sets the role and the rules for the assistant. The user message contains the actual request. In this project the system message holds the answering rules and the user message holds the numbered context passages followed by the question.

## Rules in Our System Prompt

The system prompt tells the model to use only facts from the context, not to guess, to cite passages with their numbers in square brackets, and to keep answers to at most four sentences. If the context does not contain the answer, the model must reply exactly: I don't have that information in my documents.

## Temperature

Temperature controls randomness. Low values such as 0.1 make answers more deterministic and factual, which is what a Q&A assistant needs. Higher values produce more creative but less reliable text.

## Tips

Put the most important instruction first and keep it short. Number the context passages so the model can cite them. Test prompts with questions that are answerable and with questions that are not, and check that the fallback answer is used correctly. Small models follow short, explicit rules better than long, subtle ones.
