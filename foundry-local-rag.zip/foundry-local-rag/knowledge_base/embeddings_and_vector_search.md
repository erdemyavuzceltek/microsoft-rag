# Embeddings and Vector Search

## What is an Embedding

An embedding is a list of numbers (a vector) that represents the meaning of a piece of text. An embedding model is trained so that texts with similar meaning get vectors that point in similar directions. The qwen3-embedding-0.6b model used in this project produces one vector per text.

## Cosine Similarity

Cosine similarity measures the angle between two vectors. It is the dot product of the vectors divided by the product of their lengths. The result ranges from -1 to 1: values near 1 mean very similar meaning, values near 0 mean unrelated. In this project chunks with a cosine similarity below 0.30 are ignored.

## Semantic Search Versus Keyword Search

Keyword search only finds documents that contain the exact words of the query. Semantic search compares embeddings, so a question about "memory requirements" can match a passage that talks about "RAM" even though the words differ.

## Brute-Force Search

The simplest vector search compares the question vector with every stored chunk vector and keeps the best matches. With a few thousand chunks this takes only milliseconds, so it is the approach used in this project. The stored vectors are loaded into memory once and cached until the index changes.

## Scaling Up

For hundreds of thousands of chunks brute-force search becomes slow. Larger systems use approximate nearest neighbour indexes, a SQLite extension such as sqlite-vec, or a dedicated vector database.
