# RAG Fundamentals

## What is RAG

Retrieval-Augmented Generation (RAG) is an AI design pattern with three steps. Retrieve: find the passages in your own documents that are most relevant to the question. Augment: insert those passages into the prompt as context. Generate: let the language model write an answer based on that context.

## Why RAG Reduces Hallucinations

A language model on its own only knows what it saw during training, and when it does not know something it may invent a plausible but wrong answer. This is called a hallucination. RAG reduces hallucinations because the model is given the relevant facts in the prompt and is instructed to answer only from them. It also enables source citations, so users can check where an answer came from.

## RAG Versus Context Stuffing

The simplest alternative to RAG is to paste every document into the prompt. This works for tiny collections but fails quickly: small local models have limited context windows, long prompts are slow on a laptop, and irrelevant text distracts the model. RAG sends only the few most relevant chunks, which keeps prompts short and answers focused.

## The Pipeline in This Project

Offline, an ingestion script splits documents into chunks, turns each chunk into an embedding vector and stores both in SQLite. Online, the question is embedded with the same model, the most similar chunks are found by cosine similarity, and those chunks plus the question are sent to the local chat model through Foundry Local.

## Choosing Top-K

Top-K is the number of chunks retrieved per question. This project uses a top-k of 3. Retrieving too few chunks can miss the answer; retrieving too many makes prompts longer, slower and noisier. A minimum similarity score is also applied so that unrelated chunks are dropped. If no chunk passes the threshold, the assistant says it does not know without calling the model at all.
