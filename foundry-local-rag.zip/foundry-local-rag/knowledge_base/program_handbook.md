# Summer School Program Handbook

## Overview

The Local AI Summer School is a full-time program in which beginner computer science students build a local question-answering assistant. The assistant uses Retrieval-Augmented Generation (RAG) and runs completely offline on a laptop using Microsoft Foundry Local. Students work in teams of two or three.

## Schedule

The program is divided into three phases.

Phase 1, Foundational Learning, covers weeks 1 and 2. Students learn RAG concepts, install Foundry Local, and practise embeddings, vector search, SQLite and prompt engineering.

Phase 2, Project Implementation, covers weeks 3 and 4. Week 3 is about data ingestion and the retrieval pipeline. Week 4 is about integrating the local LLM and building the user interface.

Phase 3, Testing and Documentation, covers week 5 and optionally week 6. Students test and evaluate their assistant, tune performance, write documentation and prepare the final presentation.

## Daily Rhythm

Sessions run Monday to Friday from 09:30 to 16:30. Mornings start with a 45-minute lecture, followed by hands-on lab time. A daily stand-up happens at 13:30 where every team reports progress and blockers in under two minutes.

## Milestones

By the end of week 1 every student has Foundry Local installed and can run a small model. By the end of week 2 students have a test SQLite database and can compute cosine similarity between embeddings. By the end of week 3 each team has a populated document database and a working retrieval function. By the end of week 4 each team has a working Q&A application. By the middle of week 5 test results are documented.

## Demo Day

The program ends with demo day. Each team has 10 minutes: 6 minutes of presentation and live demo, then 4 minutes of questions. The presentation must cover the problem statement, the key components, a live demo that includes one question the assistant cannot answer, and lessons learned. Teams must submit their repository and README by 12:00 on demo day.

## Grading

Projects are graded on four criteria: working functionality (40%), answer quality and evaluation (25%), code quality and documentation (20%), and the final presentation (15%).
