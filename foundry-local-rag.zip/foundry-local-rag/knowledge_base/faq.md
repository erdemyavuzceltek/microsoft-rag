# Frequently Asked Questions

## Can I use my own documents

Yes. Put Markdown (.md) or plain text (.txt) files into the knowledge_base folder and run python main.py ingest. Only new or changed files are processed.

## Do I need a GPU

No. Foundry Local runs on an ordinary laptop CPU. If a supported GPU or NPU is available it is used automatically.

## Does the assistant send my data to the internet

No. Documents, embeddings, the database and the models all stay on your computer. Internet is only needed once, to download the models the first time.

## Which interface should my team build

Every team must deliver the command-line interface. The web interface is a stretch goal for teams that finish early. Streamlit or Gradio are allowed as alternatives.

## Where do I ask for help

Mentors hold office hours every Tuesday and Thursday from 15:00 to 16:30 in Lab 2. Outside office hours post questions in the course forum.

## How is the team formed

Teams of two or three students are formed on the first day of week 1. Students may choose their own teammates.
