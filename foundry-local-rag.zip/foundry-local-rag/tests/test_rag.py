"""Unit + integration tests. Run with:  python -m pytest -q
They use the mock backend, so Foundry Local is NOT required."""
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["RAG_BACKEND"] = "mock"

from rag.chunking import chunk_text  # noqa: E402
from rag.config import FALLBACK_ANSWER, Settings  # noqa: E402
from rag.ingest import ingest  # noqa: E402
from rag.models import MockChat, MockEmbedder  # noqa: E402
from rag.pipeline import RagPipeline, build_messages  # noqa: E402
from rag.store import VectorStore  # noqa: E402


# ---------------- chunking ----------------
def test_chunks_carry_heading_path():
    text = "# Doc\n\n## Setup\n\nInstall it.\n\n### Windows\n\nUse winml."
    chunks = chunk_text(text, 200, 0)
    assert [c.section for c in chunks] == ["Doc > Setup", "Doc > Setup > Windows"]
    assert chunks[1].text == "Use winml."


def test_chunk_size_respected_and_overlap():
    para = " ".join(f"Sentence number {i} is here." for i in range(60))
    chunks = chunk_text(para, 300, 60)
    assert len(chunks) > 3
    assert all(len(c.text) <= 300 + 60 + 2 for c in chunks)
    # overlap: end of chunk N appears at start of chunk N+1
    assert chunks[1].text.split()[0] in chunks[0].text


def test_empty_text_gives_no_chunks():
    assert chunk_text("   \n\n") == []


# ---------------- store ----------------
def test_store_roundtrip_and_search():
    s = VectorStore(":memory:")
    s.upsert_document("a.md", "A", "h1", [("s", "alpha")], [[1.0, 0.0]])
    s.upsert_document("b.md", "B", "h2", [("s", "beta")], [[0.0, 1.0]])
    hits = s.search([0.9, 0.1], top_k=2)
    assert hits[0].source == "a.md" and hits[0].score > hits[1].score
    assert s.search([0.0, 1.0], top_k=2, min_score=0.5)[0].source == "b.md"
    assert len(s.search([0.0, 1.0], top_k=2, min_score=0.5)) == 1


def test_store_replace_and_dim_mismatch():
    s = VectorStore(":memory:")
    s.upsert_document("a.md", "A", "h1", [("", "x"), ("", "y")], [[1, 0], [0, 1]])
    s.upsert_document("a.md", "A", "h2", [("", "z")], [[1, 0]])
    assert s.stats()["chunks"] == 1
    with pytest.raises(ValueError):
        s.search([1, 0, 0])


# ---------------- ingest + pipeline ----------------
@pytest.fixture()
def pipeline(tmp_path):
    docs = tmp_path / "docs"
    docs.mkdir()
    (docs / "office.md").write_text("# FAQ\n\n## Office hours\n\nMentors hold office hours every Tuesday in Lab 2.\n")
    (docs / "db.md").write_text("# DB\n\n## Storage\n\nEmbeddings are stored as float32 BLOB values in SQLite.\n")
    settings = Settings(backend="mock", docs_dir=docs, db_path=tmp_path / "t.db", min_score=0.2)
    store = VectorStore(settings.db_path)
    rag = RagPipeline(settings, store, MockEmbedder(), MockChat())
    ingest(settings, store, rag.embedder, verbose=False)
    return rag, docs


def test_ingest_is_incremental(pipeline):
    rag, docs = pipeline
    r = ingest(rag.settings, rag.store, rag.embedder, verbose=False)
    assert r.unchanged == ["db.md", "office.md"] and r.chunks_embedded == 0
    (docs / "db.md").write_text("# DB\n\nChanged text about SQLite.\n")
    (docs / "office.md").unlink()
    r = ingest(rag.settings, rag.store, rag.embedder, verbose=False)
    assert r.updated == ["db.md"] and r.removed == ["office.md"]
    assert rag.store.stats()["documents"] == 1


def test_answer_cites_source(pipeline):
    rag, _ = pipeline
    ans = rag.answer_query("When are office hours?")
    assert ans.sources[0].source == "office.md"
    assert "Tuesday" in ans.answer and "[1]" in ans.answer and ans.used_llm


def test_unrelated_question_refused_without_llm(pipeline):
    rag, _ = pipeline
    ans = rag.answer_query("capital of australia")
    assert ans.answer == FALLBACK_ANSWER and not ans.used_llm


def test_empty_question(pipeline):
    rag, _ = pipeline
    assert rag.answer_query("   ").answer == "Please type a question."


def test_prompt_contains_numbered_context():
    from rag.store import SearchHit
    msgs = build_messages("Q?", [SearchHit(1, "a.md", "A", "Sec", "text one", 0.9)])
    assert msgs[0]["role"] == "system" and "ONLY" in msgs[0]["content"]
    assert "[1] (source: a.md > Sec)\ntext one" in msgs[1]["content"]


def test_web_api(pipeline):
    pytest.importorskip("flask")
    from web.server import create_app
    rag, _ = pipeline
    client = create_app(rag).test_client()
    assert client.get("/api/health").json["index"]["documents"] == 2
    r = client.post("/api/ask", json={"question": "Where are embeddings stored?"})
    assert r.status_code == 200 and r.json["sources"][0]["source"] == "db.md"
    assert client.post("/api/ask", json={}).status_code == 400
    assert client.get("/").status_code == 200
