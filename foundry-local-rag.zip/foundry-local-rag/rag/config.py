"""Central configuration. Every value can be overridden with an environment variable."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


@dataclass(frozen=True)
class Settings:
    # "foundry" = real on-device models via Foundry Local, "mock" = offline stand-ins for tests/CI
    backend: str = field(default_factory=lambda: _env("RAG_BACKEND", "foundry"))

    # Foundry Local model aliases (see `foundry model list` or the catalog)
    chat_model: str = field(default_factory=lambda: _env("RAG_CHAT_MODEL", "phi-3.5-mini"))
    embedding_model: str = field(default_factory=lambda: _env("RAG_EMBED_MODEL", "qwen3-embedding-0.6b"))
    app_name: str = field(default_factory=lambda: _env("RAG_APP_NAME", "local_rag_assistant"))

    # Paths
    docs_dir: Path = field(default_factory=lambda: Path(_env("RAG_DOCS_DIR", str(PROJECT_ROOT / "knowledge_base"))))
    db_path: Path = field(default_factory=lambda: Path(_env("RAG_DB_PATH", str(PROJECT_ROOT / "data" / "rag.db"))))

    # Chunking (characters, not tokens - simple and model independent)
    chunk_size: int = field(default_factory=lambda: int(_env("RAG_CHUNK_SIZE", "900")))
    chunk_overlap: int = field(default_factory=lambda: int(_env("RAG_CHUNK_OVERLAP", "150")))

    # Retrieval
    top_k: int = field(default_factory=lambda: int(_env("RAG_TOP_K", "3")))
    # Chunks scoring below this cosine similarity are ignored. If nothing passes,
    # the assistant says "I don't know" without calling the LLM at all.
    # Tune it with eval/run_eval.py (look at the top_score column). The mock
    # bag-of-words embedder produces much lower scores, hence its own default.
    min_score: float = field(default_factory=lambda: float(
        _env("RAG_MIN_SCORE", "0.12" if _env("RAG_BACKEND", "foundry") == "mock" else "0.30")))

    # Generation
    temperature: float = field(default_factory=lambda: float(_env("RAG_TEMPERATURE", "0.1")))
    max_tokens: int = field(default_factory=lambda: int(_env("RAG_MAX_TOKENS", "400")))

    embed_batch_size: int = 16


SUPPORTED_EXTENSIONS = {".md", ".txt"}

FALLBACK_ANSWER = "I don't have that information in my documents."


def get_settings() -> Settings:
    return Settings()
