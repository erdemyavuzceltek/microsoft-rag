"""Ingestion: read documents -> chunk -> embed -> store in SQLite.

Incremental: a document is only re-embedded when its SHA-256 changes, and
documents deleted from the folder are removed from the index.
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from pathlib import Path

from .chunking import chunk_text
from .config import SUPPORTED_EXTENSIONS, Settings
from .models import Embedder
from .store import VectorStore


@dataclass
class IngestReport:
    added: list[str]
    updated: list[str]
    unchanged: list[str]
    removed: list[str]
    chunks_embedded: int
    seconds: float

    def summary(self) -> str:
        return (f"added={len(self.added)} updated={len(self.updated)} unchanged={len(self.unchanged)} "
                f"removed={len(self.removed)} chunks_embedded={self.chunks_embedded} in {self.seconds:.1f}s")


def _title(text: str, fallback: str) -> str:
    for line in text.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return fallback


def discover(docs_dir: Path) -> list[Path]:
    return sorted(p for p in docs_dir.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS)


def ingest(settings: Settings, store: VectorStore, embedder: Embedder, rebuild: bool = False,
           verbose: bool = True) -> IngestReport:
    t0 = time.perf_counter()
    log = print if verbose else (lambda *a, **k: None)

    built_with = store.get_meta("embedding_model")
    if rebuild or (built_with and built_with != embedder.name):
        if built_with and built_with != embedder.name:
            log(f"[ingest] index was built with '{built_with}', now using '{embedder.name}' -> rebuilding")
        store.clear()

    if not settings.docs_dir.is_dir():
        raise FileNotFoundError(f"Docs folder not found: {settings.docs_dir}")

    files = discover(settings.docs_dir)
    added, updated, unchanged = [], [], []
    n_chunks = 0
    for path in files:
        source = path.relative_to(settings.docs_dir).as_posix()
        raw = path.read_text(encoding="utf-8", errors="replace")
        sha = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        previous = store.document_hash(source)
        if previous == sha:
            unchanged.append(source)
            continue
        chunks = chunk_text(raw, settings.chunk_size, settings.chunk_overlap)
        if not chunks:
            log(f"[ingest] skip empty {source}")
            continue
        # Prefix each passage with title + section before embedding: gives the
        # embedding model context the bare paragraph may lack.
        title = _title(raw, path.stem)
        to_embed = [f"{title} - {c.section}\n{c.text}" if c.section else f"{title}\n{c.text}" for c in chunks]
        vectors = embedder.embed(to_embed)
        store.upsert_document(source, title, sha, [(c.section, c.text) for c in chunks], vectors)
        n_chunks += len(chunks)
        (updated if previous else added).append(source)
        log(f"[ingest] {'updated' if previous else 'added  '} {source}: {len(chunks)} chunks")

    removed = store.delete_missing({p.relative_to(settings.docs_dir).as_posix() for p in files})
    for r in removed:
        log(f"[ingest] removed {r}")

    if n_chunks:
        store.set_meta("embedding_model", embedder.name)
        store.set_meta("dims", str(len(vectors[0])))
    return IngestReport(added, updated, unchanged, removed, n_chunks, time.perf_counter() - t0)
