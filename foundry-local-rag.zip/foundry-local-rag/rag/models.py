"""Model layer: embeddings + chat, via Microsoft Foundry Local (or offline mocks).

Foundry Local runs the models in-process on CPU/GPU/NPU. The first run downloads
the models into the local cache; after that everything works with no network.

The `mock` backend exists so the pipeline, tests and CI can run on machines
without Foundry Local. It is NOT a real model: embeddings are hashed bag-of-words
and the "LLM" just quotes the best-matching context sentence.
"""
from __future__ import annotations

import hashlib
import math
import re
import threading
import warnings
from typing import Iterator, Protocol

from .config import Settings

Message = dict  # {"role": "...", "content": "..."}


class Embedder(Protocol):
    name: str

    def embed(self, texts: list[str]) -> list[list[float]]: ...


class ChatModel(Protocol):
    name: str

    def complete(self, messages: list[Message]) -> str: ...

    def stream(self, messages: list[Message]) -> Iterator[str]: ...


# --------------------------------------------------------------------------- #
# Foundry Local
# --------------------------------------------------------------------------- #
_manager_lock = threading.Lock()
_manager = None


def _progress(label: str):
    def cb(p: float) -> None:
        print(f"\r  downloading {label}: {p:5.1f}%", end="", flush=True)
    return cb


def _get_manager(settings: Settings):
    """Initialise the Foundry Local SDK exactly once per process."""
    global _manager
    with _manager_lock:
        if _manager is None:
            try:
                from foundry_local_sdk import Configuration, FoundryLocalManager
            except ImportError as e:  # pragma: no cover - depends on user machine
                raise RuntimeError(
                    "Foundry Local SDK not installed. Windows: pip install foundry-local-sdk-winml  "
                    "| macOS/Linux: pip install foundry-local-sdk"
                ) from e
            FoundryLocalManager.initialize(Configuration(app_name=settings.app_name))
            _manager = FoundryLocalManager.instance
        return _manager


def _load_model(settings: Settings, alias: str):
    manager = _get_manager(settings)
    model = manager.catalog.get_model(alias)
    if model is None:
        available = sorted({m.alias for m in manager.catalog.list_models()})
        raise RuntimeError(f"Model alias '{alias}' not in the Foundry Local catalog. Available: {available}")
    if not model.is_cached:
        print(f"[foundry] '{alias}' not cached yet - one-time download (needs internet)...")
        model.download(_progress(alias))
        print()
    if not model.is_loaded:
        print(f"[foundry] loading '{alias}' ...")
        model.load()
    return model


class FoundryEmbedder:
    def __init__(self, settings: Settings):
        self.name = settings.embedding_model
        self._batch = settings.embed_batch_size
        self._model = _load_model(settings, self.name)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            self._client = self._model.get_embedding_client()
        self._lock = threading.Lock()

    def embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        with self._lock:
            for i in range(0, len(texts), self._batch):
                resp = self._client.generate_embeddings(texts[i:i + self._batch])
                out.extend(item.embedding for item in resp.data)
        return out


class FoundryChat:
    def __init__(self, settings: Settings):
        self.name = settings.chat_model
        self._model = _load_model(settings, self.name)
        with warnings.catch_warnings():
            # The SDK marks the OpenAI-style client as deprecated in favour of ChatSession;
            # it is still the API used in the official tutorials, so we keep it for clarity.
            warnings.simplefilter("ignore", DeprecationWarning)
            self._client = self._model.get_chat_client()
        self._client.settings.temperature = settings.temperature
        self._client.settings.max_tokens = settings.max_tokens
        self._lock = threading.Lock()  # one generation at a time on a laptop

    def complete(self, messages: list[Message]) -> str:
        with self._lock:
            resp = self._client.complete_chat(messages)
        return (resp.choices[0].message.content or "").strip()

    def stream(self, messages: list[Message]) -> Iterator[str]:
        with self._lock:
            for chunk in self._client.complete_streaming_chat(messages):
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content


# --------------------------------------------------------------------------- #
# Mock backend (tests / no Foundry Local available)
# --------------------------------------------------------------------------- #
_WORD = re.compile(r"[a-z0-9]+")
_STOP = set("a an the is are was were be to of and or in on at for with by it this that what how do does "
            "i you we can my your our as from which who when where why".split())


def _tokens(text: str) -> list[str]:
    return [w for w in _WORD.findall(text.lower()) if w not in _STOP]


class MockEmbedder:
    """Hashed bag-of-words (+ light stemming). Deterministic, dependency free."""

    name = "mock-hash-embedding"

    def __init__(self, dims: int = 512):
        self.dims = dims

    @staticmethod
    def _stem(w: str) -> str:
        for suf in ("ing", "es", "s", "ed"):
            if len(w) > 4 and w.endswith(suf):
                return w[: -len(suf)]
        return w

    def embed(self, texts: list[str]) -> list[list[float]]:
        out = []
        for t in texts:
            v = [0.0] * self.dims
            for w in _tokens(t):
                h = int(hashlib.md5(self._stem(w).encode()).hexdigest(), 16)
                v[h % self.dims] += 1.0
            n = math.sqrt(sum(x * x for x in v)) or 1.0
            out.append([x / n for x in v])
        return out


class MockChat:
    """Extractive stand-in: returns the context sentence with most question-word overlap."""

    name = "mock-extractive-chat"

    def complete(self, messages: list[Message]) -> str:
        user = messages[-1]["content"]
        question = user.split("Question:")[-1]
        q = set(_tokens(question))
        best, best_score, best_ref = None, 0, ""
        for m in re.finditer(r"\[(\d+)\][^\n]*\n(.*?)(?=\n\[\d+\]|\nQuestion:|\Z)", user, re.S):
            ref, body = m.group(1), m.group(2)
            for sent in re.split(r"(?<=[.!?])\s+", body):
                score = len(q & set(_tokens(sent)))
                if score > best_score:
                    best, best_score, best_ref = sent.strip(), score, ref
        if not best or best_score < 1:
            from .config import FALLBACK_ANSWER
            return FALLBACK_ANSWER
        return f"{best} [{best_ref}]"

    def stream(self, messages: list[Message]) -> Iterator[str]:
        yield self.complete(messages)


# --------------------------------------------------------------------------- #
def get_embedder(settings: Settings) -> Embedder:
    return MockEmbedder() if settings.backend == "mock" else FoundryEmbedder(settings)


def get_chat_model(settings: Settings) -> ChatModel:
    return MockChat() if settings.backend == "mock" else FoundryChat(settings)
