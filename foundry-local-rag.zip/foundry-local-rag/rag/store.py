"""SQLite vector store.

Schema
------
documents(id, source, title, sha256, ingested_at)
chunks(id, document_id, chunk_index, section, text, embedding BLOB, dims)
meta(key, value)            -- remembers which embedding model built the index

Embeddings are stored as little-endian float32 BLOBs (4 bytes per dimension),
which is ~4x smaller than JSON text and loads straight into numpy.
Search is brute-force cosine similarity in numpy: for a few thousand chunks this
takes milliseconds. Past ~100k chunks you would switch to an ANN index
(e.g. the sqlite-vec extension) - see docs/REPORT.md.
"""
from __future__ import annotations

import sqlite3
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS documents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source      TEXT NOT NULL UNIQUE,
    title       TEXT NOT NULL,
    sha256      TEXT NOT NULL,
    ingested_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chunks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    section     TEXT NOT NULL DEFAULT '',
    text        TEXT NOT NULL,
    embedding   BLOB NOT NULL,
    dims        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


@dataclass
class SearchHit:
    chunk_id: int
    source: str
    title: str
    section: str
    text: str
    score: float

    @property
    def citation(self) -> str:
        return f"{self.source} > {self.section}" if self.section else self.source


class VectorStore:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        if str(db_path) != ":memory:":
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._lock = threading.Lock()
        self._cache: tuple[np.ndarray, list[int]] | None = None  # (normalised matrix, chunk ids)

    # ---- meta ---------------------------------------------------------------
    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        with self._lock, self.conn:
            self.conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, value))

    # ---- writes -------------------------------------------------------------
    def document_hash(self, source: str) -> str | None:
        row = self.conn.execute("SELECT sha256 FROM documents WHERE source=?", (source,)).fetchone()
        return row["sha256"] if row else None

    def upsert_document(self, source: str, title: str, sha256: str,
                        chunks: list[tuple[str, str]], embeddings: list[list[float]]) -> int:
        """Replace a document and all its chunks atomically. chunks = [(section, text), ...]"""
        if len(chunks) != len(embeddings):
            raise ValueError("chunks and embeddings length mismatch")
        with self._lock, self.conn:
            self.conn.execute("DELETE FROM documents WHERE source=?", (source,))
            cur = self.conn.execute(
                "INSERT INTO documents(source, title, sha256, ingested_at) VALUES (?,?,?,?)",
                (source, title, sha256, datetime.now(timezone.utc).isoformat(timespec="seconds")),
            )
            doc_id = cur.lastrowid
            self.conn.executemany(
                "INSERT INTO chunks(document_id, chunk_index, section, text, embedding, dims) VALUES (?,?,?,?,?,?)",
                [
                    (doc_id, i, sec, txt, np.asarray(emb, dtype="<f4").tobytes(), len(emb))
                    for i, ((sec, txt), emb) in enumerate(zip(chunks, embeddings))
                ],
            )
        self._cache = None
        return doc_id

    def delete_missing(self, keep_sources: set[str]) -> list[str]:
        rows = self.conn.execute("SELECT source FROM documents").fetchall()
        gone = [r["source"] for r in rows if r["source"] not in keep_sources]
        with self._lock, self.conn:
            for s in gone:
                self.conn.execute("DELETE FROM documents WHERE source=?", (s,))
        if gone:
            self._cache = None
        return gone

    def clear(self) -> None:
        with self._lock, self.conn:
            self.conn.execute("DELETE FROM chunks")
            self.conn.execute("DELETE FROM documents")
            self.conn.execute("DELETE FROM meta")
        self._cache = None

    # ---- reads --------------------------------------------------------------
    def stats(self) -> dict:
        c = self.conn
        return {
            "documents": c.execute("SELECT COUNT(*) FROM documents").fetchone()[0],
            "chunks": c.execute("SELECT COUNT(*) FROM chunks").fetchone()[0],
            "embedding_model": self.get_meta("embedding_model"),
            "dims": self.get_meta("dims"),
        }

    def list_documents(self) -> list[dict]:
        rows = self.conn.execute(
            "SELECT d.source, d.title, d.ingested_at, COUNT(c.id) AS chunks FROM documents d "
            "LEFT JOIN chunks c ON c.document_id = d.id GROUP BY d.id ORDER BY d.source"
        ).fetchall()
        return [dict(r) for r in rows]

    def _matrix(self) -> tuple[np.ndarray, list[int]]:
        """Load all embeddings once and keep them in memory until the index changes."""
        if self._cache is None:
            rows = self.conn.execute("SELECT id, embedding FROM chunks ORDER BY id").fetchall()
            if not rows:
                self._cache = (np.zeros((0, 0), dtype=np.float32), [])
            else:
                m = np.vstack([np.frombuffer(r["embedding"], dtype="<f4") for r in rows])
                norms = np.linalg.norm(m, axis=1, keepdims=True)
                norms[norms == 0] = 1.0
                self._cache = (m / norms, [r["id"] for r in rows])
        return self._cache

    def search(self, query_embedding: list[float], top_k: int = 3, min_score: float = 0.0) -> list[SearchHit]:
        matrix, ids = self._matrix()
        if not ids:
            return []
        q = np.asarray(query_embedding, dtype=np.float32)
        if q.shape[0] != matrix.shape[1]:
            raise ValueError(
                f"Query embedding has {q.shape[0]} dims but the index has {matrix.shape[1]}. "
                "The index was built with a different embedding model - re-run ingestion with --rebuild."
            )
        qn = np.linalg.norm(q) or 1.0
        scores = matrix @ (q / qn)  # cosine similarity (both sides normalised)
        order = np.argsort(-scores)[:top_k]
        hits = []
        for i in order:
            if scores[i] < min_score:
                break
            row = self.conn.execute(
                "SELECT c.id, c.section, c.text, d.source, d.title FROM chunks c "
                "JOIN documents d ON d.id = c.document_id WHERE c.id=?", (ids[i],)
            ).fetchone()
            hits.append(SearchHit(row["id"], row["source"], row["title"], row["section"], row["text"],
                                  float(scores[i])))
        return hits
