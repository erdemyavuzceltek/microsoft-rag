"""The RAG pipeline: retrieve -> augment -> generate."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Iterator

from .config import FALLBACK_ANSWER, Settings, get_settings
from .models import ChatModel, Embedder, get_chat_model, get_embedder
from .store import SearchHit, VectorStore

SYSTEM_PROMPT = f"""You are a helpful assistant that answers questions using ONLY the numbered context passages provided.
Rules:
1. Use only facts stated in the context. Do not use outside knowledge and do not guess.
2. If the context does not contain the answer, reply exactly: "{FALLBACK_ANSWER}"
3. Cite the passages you used with their numbers in square brackets, e.g. [1] or [2][3].
4. Be concise: at most 4 sentences or a short bullet list."""

MAX_QUESTION_CHARS = 1000


def build_messages(question: str, hits: list[SearchHit]) -> list[dict]:
    context = "\n\n".join(f"[{i}] (source: {h.citation})\n{h.text}" for i, h in enumerate(hits, 1))
    user = f"Context:\n{context}\n\nQuestion: {question}"
    return [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}]


@dataclass
class Answer:
    question: str
    answer: str
    sources: list[SearchHit] = field(default_factory=list)
    retrieval_ms: float = 0.0
    generation_ms: float = 0.0
    used_llm: bool = False

    def to_dict(self) -> dict:
        return {
            "question": self.question,
            "answer": self.answer,
            "sources": [
                {"n": i, "source": h.source, "title": h.title, "section": h.section,
                 "score": round(h.score, 3), "text": h.text}
                for i, h in enumerate(self.sources, 1)
            ],
            "retrieval_ms": round(self.retrieval_ms, 1),
            "generation_ms": round(self.generation_ms, 1),
            "used_llm": self.used_llm,
        }


class RagPipeline:
    def __init__(self, settings: Settings | None = None, store: VectorStore | None = None,
                 embedder: Embedder | None = None, chat: ChatModel | None = None):
        self.settings = settings or get_settings()
        self.store = store or VectorStore(self.settings.db_path)
        self.embedder = embedder or get_embedder(self.settings)
        self._chat = chat  # loaded lazily: ingestion never needs the chat model

        built_with = self.store.get_meta("embedding_model")
        if built_with and built_with != self.embedder.name:
            raise RuntimeError(f"Index built with '{built_with}' but current embedder is '{self.embedder.name}'. "
                               "Run: python main.py ingest --rebuild")

    @property
    def chat(self) -> ChatModel:
        if self._chat is None:
            self._chat = get_chat_model(self.settings)
        return self._chat

    # --- Week 3: retrieval --------------------------------------------------
    def get_top_chunks(self, question: str, top_k: int | None = None) -> list[SearchHit]:
        q_vec = self.embedder.embed([question])[0]
        return self.store.search(q_vec, top_k or self.settings.top_k, self.settings.min_score)

    # --- Week 4: generation -------------------------------------------------
    def _prepare(self, question: str) -> tuple[str, list[SearchHit], float] | Answer:
        question = (question or "").strip()
        if not question:
            return Answer(question, "Please type a question.")
        question = question[:MAX_QUESTION_CHARS]
        t0 = time.perf_counter()
        hits = self.get_top_chunks(question)
        r_ms = (time.perf_counter() - t0) * 1000
        if not hits:  # nothing relevant -> refuse without calling the LLM
            return Answer(question, FALLBACK_ANSWER, [], r_ms, 0.0, False)
        return question, hits, r_ms

    def answer_query(self, question: str) -> Answer:
        prep = self._prepare(question)
        if isinstance(prep, Answer):
            return prep
        question, hits, r_ms = prep
        t1 = time.perf_counter()
        text = self.chat.complete(build_messages(question, hits))
        return Answer(question, text or FALLBACK_ANSWER, hits, r_ms, (time.perf_counter() - t1) * 1000, True)

    def stream_answer(self, question: str) -> tuple[list[SearchHit], Iterator[str]]:
        """For the CLI: returns sources immediately and a token iterator."""
        prep = self._prepare(question)
        if isinstance(prep, Answer):
            return prep.sources, iter([prep.answer])
        question, hits, _ = prep
        return hits, self.chat.stream(build_messages(question, hits))
