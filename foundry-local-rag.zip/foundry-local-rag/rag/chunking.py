"""Split documents into overlapping, heading-aware passages.

Strategy (kept deliberately simple for beginners):
1. Walk the Markdown line by line and remember the current heading path
   (e.g. "Lab Rules > Laptops"). Each chunk carries that as its `section`,
   which is later used for source citations.
2. Inside a section, group paragraphs until `chunk_size` characters is reached.
3. Start the next chunk with the tail of the previous one (`overlap`) so a
   sentence that straddles a boundary is not lost.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


@dataclass
class Chunk:
    text: str
    section: str
    index: int = 0


def _sections(text: str) -> list[tuple[str, str]]:
    """Return (heading_path, body) pairs in document order."""
    path: list[tuple[int, str]] = []
    out: list[tuple[str, list[str]]] = [("", [])]
    for line in text.splitlines():
        m = _HEADING.match(line.strip())
        if m:
            level, title = len(m.group(1)), m.group(2).strip()
            path = [p for p in path if p[0] < level] + [(level, title)]
            out.append((" > ".join(t for _, t in path), []))
        else:
            out[-1][1].append(line)
    return [(h, "\n".join(body).strip()) for h, body in out if "\n".join(body).strip()]


def _split_long(paragraph: str, size: int) -> list[str]:
    """Break a single over-long paragraph on sentence boundaries."""
    if len(paragraph) <= size:
        return [paragraph]
    sentences = re.split(r"(?<=[.!?])\s+", paragraph)
    parts, cur = [], ""
    for s in sentences:
        while len(s) > size:  # pathological: no punctuation at all
            if cur:
                parts.append(cur)
                cur = ""
            parts.append(s[:size])
            s = s[size:]
        if cur and len(cur) + 1 + len(s) > size:
            parts.append(cur)
            cur = s
        else:
            cur = f"{cur} {s}".strip()
    if cur:
        parts.append(cur)
    return parts


def chunk_text(text: str, chunk_size: int = 900, overlap: int = 150) -> list[Chunk]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    overlap = max(0, min(overlap, chunk_size // 2))
    chunks: list[Chunk] = []
    for section, body in _sections(text):
        paragraphs: list[str] = []
        for p in re.split(r"\n\s*\n", body):
            p = p.strip()
            if p:
                paragraphs.extend(_split_long(p, chunk_size))
        cur = ""
        for p in paragraphs:
            if cur and len(cur) + 2 + len(p) > chunk_size:
                chunks.append(Chunk(cur, section))
                tail = cur[-overlap:] if overlap else ""
                # start the overlap at a word boundary
                tail = tail[tail.find(" ") + 1:] if " " in tail else tail
                cur = f"{tail}\n\n{p}".strip() if tail else p
            else:
                cur = f"{cur}\n\n{p}".strip()
        if cur:
            chunks.append(Chunk(cur, section))
    for i, c in enumerate(chunks):
        c.index = i
    return chunks
