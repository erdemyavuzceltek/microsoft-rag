# Windows setup: creates .venv, installs deps, runs tests, builds the index.
# Run in PowerShell from the project folder:  powershell -ExecutionPolicy Bypass -File .\setup.ps1
$ErrorActionPreference = "Stop"
if (Get-Command py -ErrorAction SilentlyContinue) { py -3 -m venv .venv } else { python -m venv .venv }
& .\.venv\Scripts\python.exe -c "import sys; assert sys.version_info >= (3, 11), 'Python 3.11+ required'"
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
& .\.venv\Scripts\python.exe -m pytest -q
& .\.venv\Scripts\python.exe main.py ingest
Write-Host "`nDone. Activate with:  .\.venv\Scripts\Activate.ps1   then:  python main.py chat   or   python main.py serve"
