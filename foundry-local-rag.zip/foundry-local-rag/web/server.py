"""Minimal Flask backend for the browser UI. Binds to localhost only by default."""
from __future__ import annotations

from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from rag import RagPipeline

STATIC = Path(__file__).resolve().parent / "static"


def create_app(rag: RagPipeline) -> Flask:
    app = Flask(__name__, static_folder=None)

    @app.get("/")
    def index():
        return send_from_directory(STATIC, "index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "backend": rag.settings.backend,
                        "chat_model": rag.settings.chat_model if rag.settings.backend != "mock" else "mock",
                        "index": rag.store.stats(), "documents": rag.store.list_documents()})

    @app.post("/api/ask")
    def ask():
        data = request.get_json(silent=True) or {}
        question = str(data.get("question", ""))
        if not question.strip():
            return jsonify({"error": "question is required"}), 400
        try:
            return jsonify(rag.answer_query(question).to_dict())
        except Exception as e:  # surface model/runtime errors to the UI instead of a bare 500
            app.logger.exception("answer_query failed")
            return jsonify({"error": f"{type(e).__name__}: {e}"}), 500

    return app
