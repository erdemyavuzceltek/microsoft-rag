# Local RAG Assistant — Microsoft Foundry Local + SQLite

An offline question-answering assistant. It answers questions about a folder of documents by
**retrieving** the most relevant passages from a local SQLite vector store and letting a small
**on-device LLM** (via [Microsoft Foundry Local](https://learn.microsoft.com/en-us/azure/foundry-local/))
generate a cited answer. After the one-time model download, nothing leaves your computer.

This is the complete implementation of the *One-Month Project Plan: Local RAG AI Assistant with Microsoft Foundry Local*.

```
question ─► embed (qwen3-embedding-0.6b) ─► cosine search in SQLite ─► top-k chunks
                                                                         │
answer + [n] citations ◄── phi-3.5-mini (Foundry Local) ◄── system prompt + numbered context
```

## Quick start

Requirements: **Python 3.11+**, Windows 10/11 or macOS (Linux works too), 8 GB RAM minimum (16 GB recommended).

**Windows (PowerShell)**
```powershell
cd path\to\foundry-local-rag
powershell -ExecutionPolicy Bypass -File .\setup.ps1     # venv + deps + tests + ingest
.\.venv\Scripts\Activate.ps1
python main.py chat
```

**macOS / Linux**
```bash
./setup.sh
source .venv/bin/activate
python main.py chat
```

The first run downloads the two models (~ a few GB) into the Foundry Local cache — internet is needed
**once**. Every later run is fully offline.

## Commands

| Command | What it does |
|---|---|
| `python main.py ingest` | Chunk + embed + store every `.md`/`.txt` in `knowledge_base/` (incremental) |
| `python main.py ingest --rebuild` | Wipe and rebuild the index (needed after changing the embedding model) |
| `python main.py chat` | Interactive terminal chat with streaming answers and sources (plan Option A) |
| `python main.py ask "question"` | One-shot answer |
| `python main.py serve` | Browser UI at http://127.0.0.1:8000 (plan Option C: HTML + JS + Flask) |
| `python main.py stats` | Documents / chunks in the index |
| `python main.py models` | List Foundry Local catalog aliases (`*` = downloaded) |
| `python eval/run_eval.py` | Week 5 evaluation → `eval/results.md` + `results.csv` |
| `python -m pytest -q` | Unit + integration tests (use fake models, no Foundry Local needed) |

Add `--mock` before any `main.py` command (e.g. `python main.py --mock chat`) to run with fake offline
models — useful to test the plumbing on a machine without Foundry Local. Mock answers are **not** real LLM output.

## Configuration

All settings live in `rag/config.py` and can be overridden with environment variables:

| Variable | Default | Notes |
|---|---|---|
| `RAG_CHAT_MODEL` | `phi-3.5-mini` | Use `qwen2.5-0.5b` on 8 GB machines (faster, weaker) |
| `RAG_EMBED_MODEL` | `qwen3-embedding-0.6b` | Changing it requires `ingest --rebuild` |
| `RAG_TOP_K` | `3` | Chunks sent to the LLM |
| `RAG_MIN_SCORE` | `0.30` | Cosine threshold; below it the chunk is ignored. Tune with the eval |
| `RAG_CHUNK_SIZE` / `RAG_CHUNK_OVERLAP` | `900` / `150` | Characters |
| `RAG_TEMPERATURE` / `RAG_MAX_TOKENS` | `0.1` / `400` | Generation |
| `RAG_DOCS_DIR` / `RAG_DB_PATH` | `knowledge_base/` / `data/rag.db` | Paths |

PowerShell: `$env:RAG_CHAT_MODEL="qwen2.5-0.5b"` · bash: `export RAG_CHAT_MODEL=qwen2.5-0.5b`

## Using your own documents

Drop `.md` or `.txt` files into `knowledge_base/` and run `python main.py ingest`. Only new or changed
files are embedded (SHA-256 check); deleted files are removed from the index. Markdown headings are used
as section names in citations, so well-structured documents give better answers.
The included documents describe a **fictional** summer school — replace them with your own.

## Project layout

```
main.py                 CLI entry point
rag/config.py           settings (env-overridable)
rag/chunking.py         heading-aware, overlapping chunker
rag/models.py           Foundry Local embedder + chat model (and mock stand-ins)
rag/store.py            SQLite schema, float32 BLOB vectors, cosine search
rag/ingest.py           incremental ingestion pipeline
rag/pipeline.py         get_top_chunks() / answer_query() / prompt
web/server.py           Flask API (localhost only)  ·  web/static/index.html  UI
knowledge_base/         sample documents
exercises/              week 1–2 exercises (hello model, embeddings, SQL sandbox, prompts)
eval/                   questions.json + run_eval.py
tests/                  pytest suite
docs/REPORT.md          project report, design decisions, presentation outline
```

## Mapping to the plan

| Plan milestone | Where |
|---|---|
| W1 Foundry Local installed, "Hello Model" | `exercises/week1_hello_model.py`, `setup.ps1` / `setup.sh` |
| W1 skeleton project with `main.py` | `main.py`, `requirements.txt` |
| W2 embeddings + cosine similarity demo | `exercises/week2_embedding_demo.py` (`find_relevant()`) |
| W2 SQL sandbox | `exercises/week2_sql_sandbox.py` |
| W2 prompt experiments | `exercises/week2_prompt_experiment.py` |
| W3 ingestion (chunk → embed → SQLite) | `rag/chunking.py`, `rag/ingest.py`, `rag/store.py` |
| W3 `get_top_chunks(query)` | `rag/pipeline.py` |
| W4 `answer_query()` with system prompt | `rag/pipeline.py` |
| W4 UI (Option A CLI, Option C web) | `main.py chat`, `web/` |
| W4 responsible outputs + citations | system prompt, score threshold, `[n]` citations |
| W5 functional tests + evaluation | `tests/`, `eval/` |
| W6 README / report / presentation | this file, `docs/REPORT.md` |

## Troubleshooting

- **`Model alias ... not in the Foundry Local catalog`** → `python main.py models` and pick an alias from the list.
- **`Index built with 'X' but current embedder is 'Y'`** → `python main.py ingest --rebuild`.
- **Slow answers** → `RAG_CHAT_MODEL=qwen2.5-0.5b`, `RAG_TOP_K=2`, close memory-heavy apps.
- **Too many "I don't have that information"** → lower `RAG_MIN_SCORE` (check `top_score` in `eval/results.csv`).
- **Wrong/hallucinated answers** → raise `RAG_MIN_SCORE`, improve document headings, use a larger chat model.

## References

- Tech Community blog — [Building your first local RAG application with Foundry Local](https://techcommunity.microsoft.com/blog/azuredevcommunityblog/building-your-first-local-rag-application-with-foundry-local/4501968)
- Microsoft Learn — [Tutorial: Build a RAG application (Foundry Local)](https://learn.microsoft.com/en-us/azure/foundry-local/tutorials/tutorial-build-rag-app)
- Microsoft Learn — [Generate text embeddings (Foundry Local)](https://learn.microsoft.com/en-us/azure/foundry-local/how-to/how-to-generate-embeddings)
- Microsoft Learn — [Get started with Foundry Local](https://learn.microsoft.com/en-us/azure/foundry-local/get-started)
- [SQLite documentation](https://sqlite.org/docs.html)
